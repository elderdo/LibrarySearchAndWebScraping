/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.jsoup.examples;

import org.jsoup.Jsoup;
import org.jsoup.helper.Validate;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import java.io.IOException;

/**
 *
 * @author elder
 */
public class LibSearch {

    private Document document;

    public Document getDocument() {
        return document;
    }

    public LibSearch(String url) {
        try {
            document = Jsoup.connect(url).get();
        } catch (IOException e) {
            System.err.println("Unable to connect to " + url + e.getMessage());
            document = null;
        }
    }

    public static void main(String[] args) {
        LibSearch libSearch = new LibSearch("http://encore.slcl.org/iii/encore/search?target=Nintendo Switch");
        Document document = libSearch.getDocument();
        if (document != null) {
            String html = document.toString();
            Matcher matcher;
            do {
                // Java requires a backslash before a backslash literal .. so 
                // one backslash becomes 2 backslashes
                Pattern pattern = Pattern.compile("Nintendo\\s+Switch :.*\\.");
                matcher = pattern.matcher(html);
                while (matcher.find()) {
                    System.out.println(matcher.group());
                }
                pattern = Pattern.compile("href=\"([^\"]+)\">next<");
                matcher = pattern.matcher(html);
                if (matcher.find()) {
                    libSearch = new LibSearch("http://encore.slcl.org" + matcher.group(1));
                    document = libSearch.getDocument();
                    html = document.toString();
                } else {
                    html = "";
                }
            } while (!html.isEmpty());
        }
    }

}
